# ActBlue → Google Sheets Daily Sync

Pulls yesterday's ActBlue contributions into a Google Sheet every morning.
No server required — runs free on GitHub Actions.

---

## Setup (one-time, ~20 minutes)

### 1. Get your ActBlue API credentials

1. Log into ActBlue and go to **Settings → API Access**
2. Create a new API credential set
3. Copy your **Client UUID** and **Client Secret**

---

### 2. Create a Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com) and create a new sheet
2. Copy the **Sheet ID** from the URL:
   `https://docs.google.com/spreadsheets/d/**THIS_PART**/edit`

---

### 3. Create a Google Service Account

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project (or use an existing one)
3. Enable the **Google Sheets API** (APIs & Services → Enable APIs → search "Sheets")
4. Go to **IAM & Admin → Service Accounts → Create Service Account**
5. Give it any name (e.g. "actblue-sync"), click through to finish
6. Click the service account → **Keys tab → Add Key → JSON**
7. Download the JSON file — you'll need its full contents

8. **Share your Google Sheet with the service account email**
   (it looks like `name@project.iam.gserviceaccount.com`)
   Give it **Editor** access

---

### 4. Set up the GitHub repository

1. Create a new GitHub repo (can be private)
2. Upload these three files:
   - `actblue_sync.py`
   - `requirements.txt`
   - `.github/workflows/daily_sync.yml`

3. Go to **Settings → Secrets and variables → Actions → New repository secret**
   Add these four secrets:

   | Secret name                | Value                                      |
   |----------------------------|--------------------------------------------|
   | `ACTBLUE_CLIENT_UUID`      | Your ActBlue Client UUID                   |
   | `ACTBLUE_CLIENT_SECRET`    | Your ActBlue Client Secret                 |
   | `GOOGLE_SHEET_ID`          | The Sheet ID from step 2                   |
   | `GOOGLE_CREDENTIALS_JSON`  | The **entire contents** of the JSON file from step 3 |

---

### 5. Test it

- Go to **Actions** tab in your GitHub repo
- Click **ActBlue Daily Sync** → **Run workflow**
- Set `days_back` to `30` for an initial backfill, or leave at `1` for just yesterday
- Watch the logs — it should finish in under a minute

---

## What the sheet looks like

A tab called **Contributions** is created automatically with these columns:

| Column | Description |
|--------|-------------|
| Contribution ID | Unique ActBlue ID (used for dedup) |
| Date | Date of contribution |
| Amount | Dollar amount |
| Recurring Amount | If part of a recurring series |
| Donor First/Last Name | |
| Donor Email | |
| Donor Address / City / State / Zip | |
| Employer / Occupation | |
| Recipient Committee | |
| Fundraising Page | |
| Payment Type | Card, check, etc. |
| Is Mobile | Whether donated on mobile |
| Is Recurring | Part of a recurring plan |
| Refunded | Whether refunded |
| Refund Date | Date of refund if applicable |

New rows are **appended daily**. Duplicates are automatically skipped.

---

## Viewing in Excel

In Excel: **Data → Get Data → From Online Services → From Web**
Paste your Google Sheet's CSV export URL:
`https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID/export?format=csv`

Or simply open the Google Sheet in your browser and use **File → Download → Excel**.

---

## Changing the sync time

Edit `.github/workflows/daily_sync.yml` and change the cron line:
```yaml
- cron: "0 6 * * *"   # 6:00 AM UTC daily
```
Use [crontab.guru](https://crontab.guru) to build a custom schedule.
